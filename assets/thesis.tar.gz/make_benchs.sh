#!/usr/bin/env sh

FILE=int_problems_no_sww
if [ -n "$1" ] ; then
    FILE="$1"
fi

echo "process problems listed in $1"

mkdir -p benchs/

MAPOPTS="-b true"
J='-j 15'

frogmap -F "$FILE" $J $MAPOPTS 'frogtptp run beagle' -o benchs/beagle.json
frogmap -F "$FILE" $J $MAPOPTS 'frogtptp run princess' -o benchs/princess.json
frogmap -F "$FILE" $J $MAPOPTS 'frogtptp run zip-arith' -o benchs/zip-arith.json
frogmap -F "$FILE" $J $MAPOPTS 'frogtptp run zip-arith-rpo' -o benchs/zip-arith-rpo.json
