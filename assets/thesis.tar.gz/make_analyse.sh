#!/usr/bin/env sh

DIR=benchs
if [ -n "$1" ] ; then
    DIR="$1"
fi

echo "analyse directory $DIR"

cd "$DIR"
frogtptp analyse beagle=beagle.json,princess=princess.json,zip=zip-arith.json
