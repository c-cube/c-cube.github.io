#!/usr/bin/env ocaml

#use "topfind";;
#thread;;
#require "lwt.unix";;
#require "containers";;
#require "toml";;
#require "frogutils";;

module M = FrogMapState

open Lwt.Infix

let split ~files clusters =
  Lwt_list.iter_s
    (fun c ->
      let dirname = String.concat "-" (List.map String.lowercase c) in
      Lwt_process.with_process_out
        (Lwt_process.shell ("mkdir -p " ^ dirname))
        (fun p -> p#status)
      >>= fun _ ->
      Lwt_list.iter_p
        (fun f ->
          let f' = Filename.concat dirname f in
          M.read_state f >>= fun (job, res_map) ->
          (* only keep argument [a] if it contains some member of [c] *)
          let keep_arg a =
            List.exists (fun cat -> CCString.find ~sub:cat a >= 0) c
          in
          let job' = {job with M.arguments = List.filter keep_arg job.M.arguments} in
          let res_map' = M.StrMap.filter (fun a _ -> keep_arg a) res_map in
          M.write_state f' (job', res_map')
        ) files
    ) clusters

let clusters = ref []
let files = ref []
let add_cluster s =
  let groups = CCString.Split.list_cpy ~by:"," s in
  clusters := groups :: !clusters
let set_file = CCList.Ref.push files

let opts = Arg.align
  [ "-f", Arg.String set_file, " add file to split"
  ]

let () =
  Arg.parse opts add_cluster "split_clusters -f file [-f file]* a,b,c d,e f";
  Lwt_main.run (split ~files:!files !clusters);
  ()

(*
    219 ARI
     87 DAT
      5 GEG
     68 HWV
     28 NUM
      1 PUZ
      6 SEV
      2 SWV
    177 SWW
      1 SYN
      3 SYO
*)

(* doit:

  ./split_categories.ml -f zip-arith.json -f beagle.json -f princess.json ARI,NUM,GEG,PUZ,SEV,SYN,SYO  DAT  HWV  SWV,SWW
*)
