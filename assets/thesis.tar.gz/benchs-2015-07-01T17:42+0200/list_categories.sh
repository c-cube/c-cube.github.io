#!/usr/bin/env sh
sed -E 's!Problems/(.{3})/.*!\1!' int_problems | uniq -c
