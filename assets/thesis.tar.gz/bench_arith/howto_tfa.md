
How I got the files containing integer TFA problems:

    cd $TPTP/Problems/
    /bin/grep -l '^[^%].*\$real' */*=* > TFAWithReal
    /bin/grep -l '^[^%].*\$int' */*=* > TFAWithInteger
    /bin/grep -l '^[^%].*\$rat' */*=* > TFAWithRational
    /bin/grep -l "Problem  : Integer:" ARI/*=* >> TFAWithInteger
    /bin/grep -l "Problem  : Rational:" ARI/*=* >> TFAWithRational
    /bin/grep -l "Problem  : Real:" ARI/*=* >> TFAWithReal

    # remove those files (mixed)
    join TFAWithRational TFAWithReal
    join TFAWithInteger TFAWithReal

    foreach file ( TFA* )\
          sort -u $file > foo\
          mv foo $file\
    end

    # find which are theorems
    cd ..
    ./Scripts/tptp2T Form TFF and Status Theorem and Arithmetic \
        | cut -f 1 -d ' ' | /bin/grep '^[A-Z]' > Problems/TFATheorems

    sort -u TFATheorems > foo
    sed -E 's#(.{3})(.*)#\1/\1\2.p#' foo > TFATheorems

    # intersection
    join TFAWithInteger TFATheorems > TFATheoremsWithIntegers
